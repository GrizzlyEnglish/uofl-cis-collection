﻿using System;
namespace CIS200Program0
{
	public class EmptyClass
	{
		public EmptyClass()
		{
		}
	}
}
